<template>
<!--  -->
<div class="personalizedAdmin">
    <h1>vuex</h1>
</div>
<!--  -->
</template>

<script>
export default {
    data() {
        return {}
    }
}
</script>

<style scoped>

  h1{
    text-align: center;
    padding-top: 100px;
    font-weight: bold;
    font-size: 30px;
    letter-spacing: 1px;
  }
</style>
