<template>
<div class="designCode">
  <div class="designCode-header">
    <div class="versions">
      <p>2.0</p>
    </div>
    <p class="header-text">WEB端海南残联设计规范</p>
  </div>

  <div class="designCode-main">
    <div class="box-out">
      <div class="font box">
        <i class="el-icon-star-on"></i>
        <p>字体设计规范</p>
      </div>
      <div class="icon box">
        <i class="el-icon-star-on"></i>
        <p>图片使用规范</p>
      </div>
      <div class="photo box">
        <i class="el-icon-star-on"></i>
        <p>正确的设计</p>
      </div>
      <div class="component box">
        <i class="el-icon-star-on"></i>
        <p>组件使用规范</p>
      </div>
    </div>
  </div>

  <div class="designCode-footer">
    <div class="font-design">
      <div class="design-box">
        <p class="big">颜色设计及使用规范</p>
        <p class="small">基础使用规范汇集</p>
      </div>
    </div>
    <div class="center">
      <div class="font-design-content">
        <p class="number"><span>1</span>正常模式颜色使用</p>

        <table class="frist-table">
          <thead>
            <tr>
              <td></td>
              <td>颜色</td>
              <td>色号</td>
              <td>使用场景</td>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td rowspan="3" class="title">主配色</td>
              <td class="color">
                <span></span>
              </td>
              <td>#012312</td>
              <td>
                <p>用于菜单的底色</p>
              </td>
            </tr>
            <tr>
              <td class="color1">
                <span></span>
              </td>
              <td>#004332</td>
              <td>
                <p>用于各式菜单的hover</p>
              </td>
            </tr>
            <tr>
              <td class="color2">
                <span></span>
              </td>
              <td>#459d72</td>
              <td>
                <p>用于菜单的顶栏</p>
              </td>
            </tr>
          </tbody>
        </table>

        <table class="frist-table">
          <thead>
            <tr>
              <td></td>
              <td>颜色</td>
              <td>色号</td>
              <td>使用场景</td>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td rowspan="5" class="title">灰度</td>
              <td class="colora">
                <span></span>
              </td>
              <td>#666666</td>
              <td>
                <p>用于菜单的底色</p>
              </td>
            </tr>
            <tr>
              <td class="colorb">
                <span></span>
              </td>
              <td>#888888</td>
              <td>
                <p>用于各式菜单的hover</p>
              </td>
            </tr>
            <tr>
              <td class="colorc">
                <span></span>
              </td>
              <td>#999999</td>
              <td>
                <p>用于菜单的顶栏</p>
              </td>
            </tr>
            <tr>
              <td class="colord">
                <span></span>
              </td>
              <td>#b2b2b2</td>
              <td>
                <p>用于菜单的顶栏</p>
              </td>
            </tr>
            <tr>
              <td class="colore">
                <span></span>
              </td>
              <td>#cccccc</td>
              <td>
                <p>用于菜单的顶栏</p>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>



    <div class="font-design">
      <div class="design-box">
        <p class="big">字体设计及使用规范</p>
        <p class="small">基础使用规范汇集</p>
      </div>
    </div>



    <!-- 文字 -->

    <div class="center">
      <div class="font-design-content">
        <p class="number"><span>2</span>字体使用</p>
        <table class="frist-table">
          <thead>
            <tr>
              <td></td>
              <td>样式</td>
              <td>字号</td>
              <td>行间距</td>
              <td>使用场景</td>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td rowspan="3" class="title">主要</td>
              <td class="one-font">标准字</td>
              <td>35px</td>
              <td>50px</td>
              <td>
                <p>用在导航标题</p>
              </td>
            </tr>
            <tr>
              <td class="two-font">标准字</td>
              <td>32px</td>
              <td>47px</td>
              <td>
                <p>用于重要的文字/按钮操作</p>
              </td>
            </tr>
            <tr>
              <td class="three-font">标准字</td>
              <td>29px</td>
              <td>44px</td>
              <td>
                <p>用于大多数文字</p>
              </td>
            </tr>
          </tbody>
        </table>

        <div class="hr"></div>

        <table class="frist-table">
          <thead>
            <tr>
              <td></td>
              <td>样式</td>
              <td>字号</td>
              <td>行间距</td>
              <td>使用场景</td>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td rowspan="3" class="title">一般</td>
              <td class="four-font">标准字</td>
              <td>26px</td>
              <td>41px</td>
              <td>
                <p>用于辅助性文字</p>
              </td>
            </tr>
            <tr>
              <td class="five-font">标准字</td>
              <td>23px</td>
              <td>38px</td>
              <td>
                <p>用于辅助性文字</p>
              </td>
            </tr>
            <tr>
              <td class="six-font">标准字</td>
              <td>20px</td>
              <td>35px</td>
              <td>
                <p>用于菜单的顶栏</p>
              </td>
            </tr>
          </tbody>
        </table>

        <div class="hr"></div>

        <table class="frist-table">
          <thead>
            <tr>
              <td></td>
              <td>样式</td>
              <td>字号</td>
              <td>行间距</td>
              <td>使用场景</td>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td rowspan="3" class="title">次要</td>
              <td class="seven-font">标准字</td>
              <td>17px</td>
              <td>32px</td>
              <td>
                <p>用于菜单的底色</p>
              </td>
            </tr>
            <tr>
              <td class="eight-font">标准字</td>
              <td>14px</td>
              <td>29px</td>
              <td>
                <p>用于辅助性文字</p>
              </td>
            </tr>
            <tr>
              <td class="nine-font">标准字</td>
              <td>12px</td>
              <td>26px</td>
              <td>
                <p>用于菜单的顶栏</p>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="font-design">
    <div class="design-box">
      <p class="big">栏目设计及使用规范</p>
      <p class="small">基础使用规范汇集</p>
    </div>
  </div>

  <div class="center content-old">
    <div class="font-design-content">
      <p class="number"><span>3</span>栏目设计</p>
      <table class="second-table">
        <thead>
          <tr>
            <td>位置</td>
            <td>宽度</td>
            <td>高度</td>
            <td>边框</td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>头部</td>
            <td>100%</td>
            <td>50px</td>
            <td>0</td>
          </tr>
          <tr>
            <td>左侧</td>
            <td>100%</td>
            <td>250px</td>
            <td>15px</td>
          </tr>
          <tr>
            <td>正文内容</td>
            <td>100%</td>
            <td>250px</td>
            <td>15px</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- 组件设计规范 -->

  <div class="font-design">
    <div class="design-box">
      <p class="big">代码设计及使用规范</p>
      <p class="small">基础使用规范汇集</p>
    </div>
  </div>

  <div class="center content-old">
    <div class="font-design-content">
      <p class="number"><span>4</span>代码设计</p>
      <table class="third-table">
        <thead>
          <tr class="maaaa">
            <td>命名</td>
            <td>约定</td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>文件夹命名不能出现 "_" 或 "-" 字符,首字母大写</td>
            <td>css全部使用class选择器</td>
          </tr>
          <tr>
            <td>class使用 "-" 号连接符</td>
            <td>js用id选择器</td>
          </tr>
          <tr>
            <td>避免 "left" 以及相关字眼</td>
            <td>统一使用sass</td>
          </tr>
          <tr>
            <td>小驼峰式命名法</td>
            <td>不定义sass变量</td>
          </tr>

          <tr class="maaaa">
            <td>图片</td>
            <td>css结构</td>
          </tr>
          <tr>
            <td>.png (PNG-24) .jpg (压缩率8-12)</td>
            <td>src/assets/css/xx.css</td>
          </tr>

          <tr class="maaaa">
            <td>HTML代码大小写</td>
            <td>元素属性</td>
          </tr>
          <tr>
            <td>小写</td>
            <td>元素属性值使用双引号语法</td>
          </tr>
          <tr>
            <td>标签必须闭合</td>
            <td>js使用 '' </td>
          </tr>

          <tr class="maaaa">
            <td>代码缩进</td>
            <td>单行注释</td>
          </tr>
          <tr>
            <td>统一用两个空格缩进代码</td>
            <td>注释使用单行</td>
          </tr>

          <tr class="maaaa">
            <td>代码嵌套</td>
            <td>代码风格</td>
          </tr>
          <tr>
            <td>元素嵌套规范，每个块状元素独立一行</td>
            <td>树型结构</td>
          </tr>
          <tr>
            <td>段落元素与标题元素只能嵌套内联元素</td>
            <td>代码类别为单行</td>
          </tr>

          <tr class="maaaa">
            <td>媒体查询</td>
            <td>js书写规范</td>
          </tr>
          <tr>
            <td>@media screen and (max-width:940px)</td>
            <td>var sum = 10</td>
          </tr>

          <tr class="maaaa">
            <td>追加代码命名法则</td>
            <td></td>
          </tr>
          <tr>
            <td>组件命名大写开头Hello</td>
            <td></td>
          </tr>
          <tr>
            <td>组件命名大写开头Hello</td>
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="end">
    <p>不为设计而设计 而为美而付出一切</p>
    <p class="end-text">王安安</p>
  </div>
</div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
  components: {}
}
</script>

<style scoped lang="scss">
.designCode-header {
    height: 400px;
    background-color: #2b83f9;
    background-image: linear-gradient(143deg, #2945cb 20%, #2b83f9 81%, #3a9dff);
    padding-top: 100px;
    color: #fff;
    .versions {
        height: 200px;
        width: 200px;
        margin: 0 auto;
        border: 1px solid #fff;
        border-radius: 200px;
        p {
            line-height: 200px;
            text-align: center;
            font-size: 100px;
            font-weight: 100;
            margin: 0;
        }
    }
    .header-text {
        text-align: center;
        padding-top: 50px;
        font-size: 40px;
        letter-spacing: 3px;
        font-weight: 100;
    }
}
.designCode-main {
    height: 300px;
    background: #F8F6F7;
    padding-top: 150px;
    .box-out {
        width: 900px;
        margin: 0 auto;
    }
    .box {
        height: 100px;
        width: 100px;
        background: #2b83f9;
        border-radius: 100px;
        float: left;
        margin-left: 100px;
        text-align: center;
        i {
            color: #fff;
            font-size: 35px;
            line-height: 100px;
        }
        p {
            font-size: 15px;
            padding-top: 5px;
            color: #676767;
        }
    }
}

.designCode-footer {
    background: #F8F6F7;
    .center {
        width: 900px;
        margin: 0 auto;
        padding-bottom: 80px;
    }
    .font-design {
        height: 130px;
        background: #2b83f9;
        padding-top: 60px;
        .design-box {
            width: 400px;
            margin: 0 auto;
            color: #fff;
            .big {
                font-size: 40px;
                font-weight: 100;
                margin-bottom: 0;
                letter-spacing: 1px;
            }
            .small {
                font-size: 12px;
                font-weight: 300;
                text-align: right;
                padding-top: 10px;
                padding-right: 40px;
                letter-spacing: 1px;
            }
        }
    }
    .font-design-content {
        padding-top: 80px;
        .number {
            height: 40px;
            line-height: 40px;
            font-size: 23px;
            color: #2b83f9;
            margin-bottom: 40px;
            span {
                height: 40px;
                width: 40px;
                font-size: 20px;
                color: #fff;
                margin-right: 20px;
                display: inline-block;
                border-radius: 30px;
                text-align: center;
                background: #2b83f9;
            }
        }
        .hr {
            color: #000;
            background: #E2E3E6;
            height: 1px;
            margin: 50px;
        }
        .frist-table {
            text-align: center;
            margin: 0 50px;
            .title {
                font-size: 17px;
                font-weight: 400;
                color: #929393;
            }
            .one-font {
                font-size: 35px;
            }
            .two-font {
                font-size: 32px;
            }
            .three-font {
                font-size: 29px;
            }
            .four-font {
                font-size: 26px;
            }
            .five-font {
                font-size: 23px;
            }
            .six-font {
                font-size: 20px;
            }
            .seven-font {
                font-size: 17px;
            }
            .eight-font {
                font-size: 14px;
            }
            .nine-font {
                font-size: 12px;
            }
            thead {
                td {
                    height: 60px;
                    width: 300px;
                    font-size: 17px;
                    font-weight: 400;
                    color: #929393;
                }
                td:nth-child(1) {
                    width: 100px;
                }
            }
            tbody {
                td {
                    height: 50px;
                    // border: 1px solid #000;
                }
                td:last-child {
                    color: #000;
                    p {
                        margin: 0;
                    }
                    p:last-child {
                        color: #6c6b6b;
                        font-size: 12px;
                    }
                }
                .color {
                    padding-top: 4px;
                    span {
                        background: #012312;
                        height: 35px;
                        width: 110px;
                        display: inline-block;
                    }
                }
                .color1 {
                    padding-top: 4px;
                    span {
                        background: #004332;
                        height: 35px;
                        width: 110px;
                        display: inline-block;
                    }
                }
                .color2 {
                    padding-top: 4px;
                    span {
                        background: #459d72;
                        height: 35px;
                        width: 110px;
                        display: inline-block;
                    }
                }
                .colora {
                    background: #666666;
                    height: 35px;
                    width: 110px;
                    display: inline-block;
                }
                .colorb {
                    background: #888888;
                    height: 35px;
                    width: 110px;
                    display: inline-block;
                }
                .colorc {
                    background: #999999;
                    height: 35px;
                    width: 110px;
                    display: inline-block;
                }
                .colord {
                    background: #b2b2b2;
                    height: 35px;
                    width: 110px;
                    display: inline-block;
                }
                .colore {
                    background: #cccccc;
                    height: 35px;
                    width: 110px;
                    display: inline-block;
                }
                .colorf {
                    background: #f2f4f5;
                    height: 35px;
                    width: 110px;
                    display: inline-block;
                }
                .colorg {
                    background: rgba(0, 0, 0,.05);
                    height: 35px;
                    width: 110px;
                    display: inline-block;
                }
                .colorh {
                    background: rgba(0, 0, 0,.10);
                    height: 35px;
                    width: 110px;
                    display: inline-block;
                }
            }
        }
    }
    .second-table {
        margin: 0 250px;
        text-align: center;
        font-size: 15px;
        tr {
            border: 1px solid rgba(0,0,0,.10);
            td {
                border: 1px solid rgba(0,0,0,.10);
            }
        }
        thead {
            font-size: 16px;
            color: #fff;
            background: #2b83f9;
        }
        tbody {
            td:nth-child(1) {
                color: #000;
                font-size: 16px;
            }
        }
        td {
            height: 50px;
            width: 100px;
        }
    }
    .third-table {
        margin: 0 50px;
        text-align: center;
        font-size: 15px;
        tr {
            border: 1px solid rgba(0,0,0,.05);
            height: 50px;
            width: 300px;
            td {
                border: 1px solid rgba(0,0,0,.05);
                height: 50px;
                width: 400px;
            }
        }
        .maaaa {
            background: #2b83f9;
            color: #fff;
            font-weight: bold;
        }
    }
}

.end {
    height: 300px;
    background-color: #2b83f9;
    background-image: linear-gradient(143deg,#2945cb 20%,#2b83f9 81%,#3a9dff);
    position: relative;
    p {
        text-align: center;
        line-height: 300px;
        color: #fff;
        font-weight: 100;
        font-size: 40px;
        letter-spacing: 2px;
        margin: 0;
    }
    .end-text {
        position: absolute;
        bottom: 50px;
        right: 200px;
        line-height: 20px;
        font-size: 15px;
        font-weight: 300;
    }
}


.designCode{
  height:100%;
  overflow-y:scroll;
}
.font-design-content {
    padding-top: 80px;
    .number {
        height: 40px;
        line-height: 40px;
        font-size: 23px;
        color: #2b83f9;
        margin-bottom: 40px;
        span {
            height: 40px;
            width: 40px;
            font-size: 20px;
            color: #fff;
            margin-right: 20px;
            display: inline-block;
            border-radius: 30px;
            text-align: center;
            background: #2b83f9;
        }
    }
}
.font-design {
    height: 130px;
    background: #2b83f9;
    padding-top: 60px;
    .design-box {
        width: 400px;
        margin: 0 auto;
        color: #fff;
        .big {
            font-size: 40px;
            font-weight: 100;
            margin-bottom: 0;
            letter-spacing: 1px;
        }
        .small {
            font-size: 12px;
            font-weight: 300;
            text-align: right;
            padding-top: 10px;
            padding-right: 40px;
            letter-spacing: 1px;
        }
    }
}

.maaaa{
  background: #2b83f9;
  color:#fff;
}

.second-table thead{
  background: #2b83f9;
  color:#fff;
}

.content-old  {
    width: 900px;
    margin: 0 auto;
    table {
        width: 650px;
        margin: 0 auto;
        text-align: center;
        margin-bottom: 100px;
        tr {
            border: 1px solid rgba(0,0,0,1);
            td {
                border: 1px solid rgba(0,0,0,1);
                padding: 15px 30px;
            }
        }
    }

}
</style>
