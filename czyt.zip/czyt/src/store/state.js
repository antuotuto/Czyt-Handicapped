const state = {
  singer: true,
  logo: true
}

export default state
