export const singer = state => state.singer

export const logo = state => state.logo
