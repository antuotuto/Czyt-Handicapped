export const SET_SINGER = 'SET_SINGER'

export const SET_LOGO = 'SET_LOGO'
