{
  "success": false,
  "status": 500,
  "message": "系统异常",
  "error": "系统异常",
  "timestamp": 1503020328752,
  "data": {}
} {
  "success": true,
  "status": 200,
  "message": "成功",
  "error": "",
  "timestamp": 1503020243670,
  "data": {
    "list": {
      "errorBean": false,
      "id": null,
      "name": null,
      "address": null,
      "birthday": null,
      "createDate": null,
      "updateDate": null
    }
  }
} {
  "success": true,
  "status": 200,
  "message": "成功",
  "error": "",
  "timestamp": 1503020110502,
  "data": {
    "list": {
      "aaa0": "ttt0",
      "aaa9": "ttt9",
      "aaa6": "ttt6",
      "aaa5": "ttt5",
      "aaa8": "ttt8",
      "aaa7": "ttt7",
      "aaa2": "ttt2",
      "aaa1": "ttt1",
      "aaa4": "ttt4",
      "aaa3": "ttt3"
    }
  }
} {
  "success": true,
  "status": 200,
  "message": "成功",
  "error": "",
  "timestamp": 1503020702920,
  "data": {
    "permission": "add,update,delete",
    "pagination": {
      "totalCount": 100,
      "totalPage": 10
    },
    "list": ["aaa0", "aaa1", "aaa2", "aaa3", "aaa4", "aaa5", "aaa6", "aaa7", "aaa8", "aaa9"]
  }
}
