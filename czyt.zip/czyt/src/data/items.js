const items = [
  {
    title:'我喜欢这样的自己',
    author:'海外网',
    description: '陆慷表示，对媒体披露的一些情况，在有关国家官方作出澄清前，我们不便作出评论。至于你提到的涉及东北亚地区安全稳定的问题，你非常清楚中方的原则立场，我们一直认为，半岛局势有它极其复杂敏感的一面，维护半岛和平稳定符合所有有关各方利益，有关各方都应当为此作出建设性努力',
    cover:'http://mpic.haiwainet.cn/thumb/d/uploadfile/20170525/1495706826872738,w_480.jpg',
    date:'2015-05-28',
    avatar:'http://ooi407n8x.bkt.clouddn.com/an.jpg'
  },
  {
    title:'美国两艘核潜艇停在朝鲜半岛附近海域 中方回应',
    author:'海外网',
    description: '陆慷表示，对媒体披露的一些情况，在有关国家官方作出澄清前，我们不便作出评论。至于你提到的涉及东北亚地区安全稳定的问题，你非常清楚中方的原则立场，我们一直认为，半岛局势有它极其复杂敏感的一面，维护半岛和平稳定符合所有有关各方利益，有关各方都应当为此作出建设性努力',
    cover:'http://mpic.haiwainet.cn/thumb/d/uploadfile/20170525/1495706826872738,w_480.jpg',
    date:'2015-05-28',
    avatar:'http://ooi407n8x.bkt.clouddn.com/an.jpg'
  },
  {
    title:'美国两艘核潜艇停在朝鲜半岛附近海域 中方回应',
    author:'海外网',
    description: '陆慷表示，对媒体披露的一些情况，在有关国家官方作出澄清前，我们不便作出评论。至于你提到的涉及东北亚地区安全稳定的问题，你非常清楚中方的原则立场，我们一直认为，半岛局势有它极其复杂敏感的一面，维护半岛和平稳定符合所有有关各方利益，有关各方都应当为此作出建设性努力',
    cover:'http://mpic.haiwainet.cn/thumb/d/uploadfile/20170525/1495706826872738,w_480.jpg',
    date:'2015-05-28',
    avatar:'http://ooi407n8x.bkt.clouddn.com/an.jpg'
  },
  {
    title:'美国两艘核潜艇停在朝鲜半岛附近海域 中方回应',
    author:'海外网',
    description: '陆慷表示，对媒体披露的一些情况，在有关国家官方作出澄清前，我们不便作出评论。至于你提到的涉及东北亚地区安全稳定的问题，你非常清楚中方的原则立场，我们一直认为，半岛局势有它极其复杂敏感的一面，维护半岛和平稳定符合所有有关各方利益，有关各方都应当为此作出建设性努力',
    cover:'http://mpic.haiwainet.cn/thumb/d/uploadfile/20170525/1495706826872738,w_480.jpg',
    date:'2015-05-28',
    avatar:'http://ooi407n8x.bkt.clouddn.com/an.jpg'
  },
  {
    title:'美国两艘核潜艇停在朝鲜半岛附近海域 中方回应',
    author:'海外网',
    description: '陆慷表示，对媒体披露的一些情况，在有关国家官方作出澄清前，我们不便作出评论。至于你提到的涉及东北亚地区安全稳定的问题，你非常清楚中方的原则立场，我们一直认为，半岛局势有它极其复杂敏感的一面，维护半岛和平稳定符合所有有关各方利益，有关各方都应当为此作出建设性努力',
    cover:'http://mpic.haiwainet.cn/thumb/d/uploadfile/20170525/1495706826872738,w_480.jpg',
    date:'2015-05-28',
    avatar:'http://ooi407n8x.bkt.clouddn.com/an.jpg'
  },
  {
    title:'美国两艘核潜艇停在朝鲜半岛附近海域 中方回应',
    author:'海外网',
    description: '陆慷表示，对媒体披露的一些情况，在有关国家官方作出澄清前，我们不便作出评论。至于你提到的涉及东北亚地区安全稳定的问题，你非常清楚中方的原则立场，我们一直认为，半岛局势有它极其复杂敏感的一面，维护半岛和平稳定符合所有有关各方利益，有关各方都应当为此作出建设性努力',
    cover:'http://mpic.haiwainet.cn/thumb/d/uploadfile/20170525/1495706826872738,w_480.jpg',
    date:'2015-05-28',
    avatar:'http://ooi407n8x.bkt.clouddn.com/an.jpg'
  },
  {
    title:'美国两艘核潜艇停在朝鲜半岛附近海域 中方回应',
    author:'海外网',
    description: '陆慷表示，对媒体披露的一些情况，在有关国家官方作出澄清前，我们不便作出评论。至于你提到的涉及东北亚地区安全稳定的问题，你非常清楚中方的原则立场，我们一直认为，半岛局势有它极其复杂敏感的一面，维护半岛和平稳定符合所有有关各方利益，有关各方都应当为此作出建设性努力',
    cover:'http://mpic.haiwainet.cn/thumb/d/uploadfile/20170525/1495706826872738,w_480.jpg',
    date:'2015-05-28',
    avatar:'http://ooi407n8x.bkt.clouddn.com/an.jpg'
  },
  {
    title:'美国两艘核潜艇停在朝鲜半岛附近海域 中方回应',
    author:'海外网',
    description: '陆慷表示，对媒体披露的一些情况，在有关国家官方作出澄清前，我们不便作出评论。至于你提到的涉及东北亚地区安全稳定的问题，你非常清楚中方的原则立场，我们一直认为，半岛局势有它极其复杂敏感的一面，维护半岛和平稳定符合所有有关各方利益，有关各方都应当为此作出建设性努力',
    cover:'http://mpic.haiwainet.cn/thumb/d/uploadfile/20170525/1495706826872738,w_480.jpg',
    date:'2015-05-28',
    avatar:'http://ooi407n8x.bkt.clouddn.com/an.jpg'
  },
  {
    title:'美国两艘核潜艇停在朝鲜半岛附近海域 中方回应',
    author:'海外网',
    description: '陆慷表示，对媒体披露的一些情况，在有关国家官方作出澄清前，我们不便作出评论。至于你提到的涉及东北亚地区安全稳定的问题，你非常清楚中方的原则立场，我们一直认为，半岛局势有它极其复杂敏感的一面，维护半岛和平稳定符合所有有关各方利益，有关各方都应当为此作出建设性努力',
    cover:'http://mpic.haiwainet.cn/thumb/d/uploadfile/20170525/1495706826872738,w_480.jpg',
    date:'2015-05-28',
    avatar:'http://ooi407n8x.bkt.clouddn.com/an.jpg'
  },
  {
    title:'美国两艘核潜艇停在朝鲜半岛附近海域 中方回应',
    author:'海外网',
    description: '陆慷表示，对媒体披露的一些情况，在有关国家官方作出澄清前，我们不便作出评论。至于你提到的涉及东北亚地区安全稳定的问题，你非常清楚中方的原则立场，我们一直认为，半岛局势有它极其复杂敏感的一面，维护半岛和平稳定符合所有有关各方利益，有关各方都应当为此作出建设性努力',
    cover:'http://mpic.haiwainet.cn/thumb/d/uploadfile/20170525/1495706826872738,w_480.jpg',
    date:'2015-05-28',
    avatar:'http://ooi407n8x.bkt.clouddn.com/an.jpg'
  },
]

export {items}
